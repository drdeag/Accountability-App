
package com.dev.accountability

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                DashboardScreen()
            }
        }
    }
}

enum class MealStatus { UPCOMING, DONE, MISSED, SKIPPED }
data class MealItem(val label: String, val status: MealStatus)

@Composable
fun DashboardScreen() {
    var paused by remember { mutableStateOf(false) }
    val meals = remember {
        mutableStateListOf(
            MealItem("Breakfast", MealStatus.MISSED),
            MealItem("Lunch", MealStatus.UPCOMING),
            MealItem("Dinner", MealStatus.UPCOMING),
            MealItem("Snack/Supplement", MealStatus.UPCOMING)
        )
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Accountability") },
                navigationIcon = {
                    TextButton(onClick = { paused = !paused }) {
                        Text(if (paused) "Resume" else "Pause")
                    }
                },
                actions = {
                    TextButton(onClick = { /* settings */ }) { Text("Settings") }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { /* camera placeholder */ }) { Text("📷") }
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Text("Current Streak: 0 days", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Next Meal: Lunch in 1h 12m")
            Spacer(Modifier.height(12.dp))
            LazyColumn {
                items(meals.size) { i ->
                    val meal = meals[i]
                    MealRow(
                        label = meal.label,
                        status = meal.status,
                        onCamera = { meals[i] = meal.copy(status = MealStatus.DONE) },
                        onManual = { meals[i] = meal.copy(status = MealStatus.DONE) },
                        onSkip = { meals[i] = meal.copy(status = MealStatus.SKIPPED) }
                    )
                    Spacer(Modifier.height(8.dp))
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { /* history */ }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("📆 History")
            }
        }
    }
}

@Composable
fun MealRow(label: String, status: MealStatus, onCamera: ()->Unit, onManual: ()->Unit, onSkip: ()->Unit) {
    Surface(tonalElevation = 2.dp) {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontWeight = FontWeight.SemiBold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(when(status){ MealStatus.DONE->"✅"; MealStatus.MISSED->"🔴"; MealStatus.SKIPPED->"⚪"; MealStatus.UPCOMING->"⏳"})
                Spacer(Modifier.width(12.dp))
                Text("📷", modifier = Modifier.padding(horizontal = 6.dp))
                Text("✏", modifier = Modifier.padding(horizontal = 6.dp))
                Text("❌", modifier = Modifier.padding(horizontal = 6.dp))
            }
        }
    }
}
